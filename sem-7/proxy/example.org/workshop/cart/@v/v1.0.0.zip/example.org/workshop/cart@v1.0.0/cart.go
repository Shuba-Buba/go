package cart

import "example.org/workshop/catalog"

// Total returns the cost of two packs of tea.
func Total() int {
	return catalog.TeaPrice() * 2
}
