package catalog

// TeaPrice returns the current unit price of tea.
func TeaPrice() int {
	return 120
}

// Version returns the version of this teaching fixture.
func Version() string {
	return "v1.2.0"
}
