package catalog

// TeaPrice returns the current unit price of tea.
func TeaPrice() int {
	return 110
}

// Version returns the version of this teaching fixture.
func Version() string {
	return "v1.1.0"
}
