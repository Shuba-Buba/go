package report

import "example.org/workshop/catalog"

// Price returns the unit price used in the report.
func Price() int {
	return catalog.TeaPrice()
}
